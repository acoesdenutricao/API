module.exports = {
    dialect: 'postgres',
    host: 'db',
    username: 'root',
    password: 'apiuser',
    database: 'api',
    define: {
        timestamps: true,
        underscored: true
    }
};