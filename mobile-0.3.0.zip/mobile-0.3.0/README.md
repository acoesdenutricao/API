# Ações de Nutrição - PDS - Mobile

[![Build Status](https://img.shields.io/travis/cakephp/app/master.svg?style=flat-square)](https://travis-ci.org/cakephp/app)




## Pré-requisitos

Antes de iniciar, certifique-se de cumprir os seguintes requisitos:
<!--- Estes são alguns exemplos de requisitos. Adicione, duplique e remove como necessário --->
* Você deve possuir a última versão do ...

## Como executar

Para fazer o deploy da aplicação siga os seguintes passos:

Linux:
```
* Passo a passo do nosso ambiente:
 - ...

* 
```

## Usando Gerenciador pericial

Para usar Ações de Nutrição, estas são as opções:
* ...
 

## Evolução da Aplicação
* Primeira Sprint
    * Base inicial

* Segunda sprint
    *

## Contribuidores

As seguintes pessoas contribuiram para este projeto:

* Igor Galvan (https://github.com/igorbgalvan)
* Jean Henrique (https://github.com/jeanhjaques)

## Licença de uso

Este é um projeto privado com direitos reservados para a Universidade Federal do Mato Grosso do Sul.
