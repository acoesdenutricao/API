import * as SQLite from 'expo-sqlite'

const db = SQLite.openDatabase("db.db")

export default db